
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import time

class LeNet5(nn.Module):
    def __init__(self):
        super(LeNet5, self).__init__()
        self.conv1 = nn.Conv2d(in_channels=1, out_channels=6, kernel_size=5, stride=1, padding=2)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.conv2 = nn.Conv2d(in_channels=6, out_channels=16, kernel_size=5, stride=1)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.fc1 = nn.Linear(in_features=16 * 5 * 5, out_features=120)
        self.relu3 = nn.ReLU()
        
        self.fc2 = nn.Linear(in_features=120, out_features=84)
        self.relu4 = nn.ReLU()
        
        self.fc3 = nn.Linear(in_features=84, out_features=10)

    def forward(self, x):
        x = self.pool1(self.relu1(self.conv1(x)))
        x = self.pool2(self.relu2(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = self.relu3(self.fc1(x))
        x = self.relu4(self.fc2(x))
        x = self.fc3(x)
        return x

def load_data(batch_size=64):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])

    train_dataset = torchvision.datasets.MNIST(
        root='./data',
        train=True,
        download=True,
        transform=transform
    )

    test_dataset = torchvision.datasets.MNIST(
        root='./data',
        train=False,
        download=True,
        transform=transform
    )

    train_loader = torch.utils.data.DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True
    )

    test_loader = torch.utils.data.DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False
    )

    return train_loader, test_loader

def train(model, train_loader, criterion, optimizer, device, epochs=10):
    model.train()
    train_losses = []
    train_accuracies = []
    
    start_time = time.time()

    for epoch in range(epochs):
        running_loss = 0.0
        correct = 0
        total = 0

        for i, (images, labels) in enumerate(train_loader):
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        epoch_loss = running_loss / len(train_loader)
        epoch_acc = 100 * correct / total
        train_losses.append(epoch_loss)
        train_accuracies.append(epoch_acc)
        
        elapsed_time = time.time() - start_time
        print(f'Epoch {epoch+1}/{epochs}, Loss: {epoch_loss:.4f}, Accuracy: {epoch_acc:.2f}%, Time: {elapsed_time:.2f}s')

    total_time = time.time() - start_time
    return train_losses, train_accuracies, total_time

def test(model, test_loader, criterion, device):
    model.eval()
    test_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            test_loss += loss.item()

            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    test_loss /= len(test_loader)
    accuracy = 100 * correct / total
    print(f'\nTest Loss: {test_loss:.4f}, Accuracy: {accuracy:.2f}%')

    return test_loss, accuracy

def main():
    torch.manual_seed(42)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'使用设备: {device}')
    print(f'是否使用GPU: {torch.cuda.is_available()}')

    batch_size = 64
    epochs = 10
    learning_rate = 0.001
    
    print(f'训练参数: 批量大小={batch_size}, 训练轮数={epochs}, 学习率={learning_rate}')

    train_loader, test_loader = load_data(batch_size=batch_size)

    model = LeNet5().to(device)
    print('\nLeNet-5 模型结构:')
    print(model)
    
    print('\n各层参数统计:')
    total_params = 0
    for name, param in model.named_parameters():
        layer_params = param.numel()
        total_params += layer_params
        print(f'{name}: {layer_params} 参数')
    print(f'总参数数量: {total_params}')

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    
    print(f'\n优化器: Adam, 损失函数: CrossEntropyLoss')

    print('\n开始训练...')
    train_losses, train_accuracies, total_time = train(model, train_loader, criterion, optimizer, device, epochs=epochs)

    print(f'\n训练完成! 总训练时间: {total_time:.2f}秒')

    print('\n开始测试...')
    test_loss, test_accuracy = test(model, test_loader, criterion, device)

    torch.save(model.state_dict(), 'lenet5_mnist.pth')
    print('\n模型已保存为 lenet5_mnist.pth')

    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.plot(train_losses, label='Training Loss')
    plt.title('Training Loss Over Epochs')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    
    plt.subplot(1, 2, 2)
    plt.plot(train_accuracies, label='Training Accuracy')
    plt.title('Training Accuracy Over Epochs')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy (%)')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('training_curves.png')
    print('训练曲线已保存为 training_curves.png')

    with open('training_report.txt', 'w') as f:
        f.write('LeNet-5 训练报告\n')
        f.write('=' * 40 + '\n\n')
        f.write('训练参数:\n')
        f.write(f'  批量大小: {batch_size}\n')
        f.write(f'  训练轮数: {epochs}\n')
        f.write(f'  学习率: {learning_rate}\n')
        f.write(f'  优化器: Adam\n')
        f.write(f'  损失函数: CrossEntropyLoss\n')
        f.write(f'  使用GPU: {torch.cuda.is_available()}\n')
        f.write(f'  总训练时间: {total_time:.2f}秒\n\n')
        
        f.write('模型结构参数:\n')
        f.write('=' * 40 + '\n')
        f.write('| 层名称 | 输入尺寸 | 输出尺寸 | 参数数量 |\n')
        f.write('|--------|----------|----------|----------|\n')
        f.write('| conv1  | 1x28x28  | 6x28x28  | 156      |\n')
        f.write('| pool1  | 6x28x28  | 6x14x14  | 0        |\n')
        f.write('| conv2  | 6x14x14  | 16x10x10 | 2416     |\n')
        f.write('| pool2  | 16x10x10 | 16x5x5   | 0        |\n')
        f.write('| fc1    | 400      | 120      | 48120    |\n')
        f.write('| fc2    | 120      | 84       | 10164    |\n')
        f.write('| fc3    | 84       | 10       | 850      |\n')
        f.write('=' * 40 + '\n')
        f.write(f'总参数数量: {total_params}\n\n')
        
        f.write('训练过程:\n')
        f.write('=' * 40 + '\n')
        for epoch in range(epochs):
            f.write(f'Epoch {epoch+1}: Loss={train_losses[epoch]:.4f}, Accuracy={train_accuracies[epoch]:.2f}%\n')
        f.write('\n')
        
        f.write('测试结果:\n')
        f.write('=' * 40 + '\n')
        f.write(f'测试损失: {test_loss:.4f}\n')
        f.write(f'测试准确率: {test_accuracy:.2f}%\n')
    
    print('训练报告已保存为 training_report.txt')

if __name__ == '__main__':
    main()

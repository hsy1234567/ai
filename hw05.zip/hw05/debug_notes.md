
# 调试笔记

## 问题记录

### 问题1：ModuleNotFoundError: No module named 'torch'

**现象**：
```
Traceback (most recent call last):
  File "E:\dm\AI\CNN\simple_cnn_mnist.py", line 2, in <module>
    import torch
ModuleNotFoundError: No module named 'torch'
```

**原因分析**：
当前Python环境未安装PyTorch深度学习框架及其相关依赖。代码中导入了`torch`、`torch.nn`、`torch.optim`、`torchvision`等模块，但这些模块尚未安装。

**修改点**：
需要在运行代码前安装必要的依赖包。可以通过以下命令安装：

```bash
# 使用pip安装（推荐）
pip install torch torchvision matplotlib numpy

# 或者使用conda安装
conda install torch torchvision matplotlib numpy
```

**解决步骤**：
1. 打开终端或命令提示符
2. 确保当前环境有网络连接
3. 执行上述安装命令之一
4. 等待安装完成后重新运行代码

### 问题2：pip安装失败（网络问题）

**现象**：
```
WARNING: Retrying (Retry(total=4, connect=None, read=None, redirect=None, status=None)) after connection broken by 'NewConnectionError('<pip._vendor.urllib3.connection.HTTPSConnection object at 0x000002609598ECF0>: Failed to establish a new connection: [Errno 11003] getaddrinfo failed')': /simple/torch/
ERROR: Could not find a version that satisfies the requirement torch (from versions: none)
```

**原因分析**：
网络连接失败，无法访问PyPI服务器下载依赖包。错误码11003表示DNS解析失败。

**修改点**：
1. 检查网络连接状态
2. 确保网络可以访问外部网站
3. 如果使用代理，检查代理配置是否正确
4. 尝试切换网络或使用镜像源

**备选方案**：
使用国内PyPI镜像源：
```bash
pip install torch torchvision matplotlib numpy -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 问题3：conda命令未找到

**现象**：
```
conda : 无法将“conda”项识别为 cmdlet、函数、脚本文件或可运行程序的名称。
```

**原因分析**：
当前环境未配置conda环境变量，或未安装Anaconda/Miniconda。

**修改点**：
1. 如果已安装Anaconda/Miniconda，需要配置环境变量
2. 或者直接使用pip安装依赖

## 代码运行前提条件

1. **Python版本**：建议Python 3.8及以上
2. **必需依赖**：
   - torch (PyTorch深度学习框架)
   - torchvision (计算机视觉工具包)
   - matplotlib (绘图库)
   - numpy (科学计算库)

3. **可选依赖**：
   - CUDA (如果使用GPU加速)

## 建议解决方案

1. **方案一**：使用pip安装依赖
```bash
pip install torch torchvision matplotlib numpy
```

2. **方案二**：使用国内镜像源（网络受限环境）
```bash
pip install torch torchvision matplotlib numpy -i https://pypi.tuna.tsinghua.edu.cn/simple
```

3. **方案三**：从PyTorch官网获取安装命令（推荐）
   - 访问 https://pytorch.org/get-started/locally/
   - 根据系统和CUDA版本获取对应安装命令

## 验证安装

安装完成后，可通过以下命令验证：
```bash
python -c "import torch; print(torch.__version__)"
```

预期输出：
```
2.x.x
```

## 运行代码

依赖安装成功后，运行以下命令执行代码：
```bash
python simple_cnn_mnist.py
```

预期输出：
- 设备信息（CPU或GPU）
- 模型结构
- 每个epoch的训练损失和准确率
- 测试集损失和准确率（目标：>98%）
- 模型保存提示
